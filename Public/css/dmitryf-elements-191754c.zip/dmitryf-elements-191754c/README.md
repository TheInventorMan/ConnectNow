LESS Elements
=============

A set of useful mixins for LESS, the CSS pre-processor: <http://lesscss.org>

More information and usage examples over at: <http://lesselements.com>

Examples page of all the mixins here: <http://lesselements.com/tests>

Oreolek has a good fork with the mixins organized under namespaces here: https://github.com/Oreolek/elements 
I recommend going with that if you use other frameworks like Bootstrap to avoid clashes.

TextMate bundle: <https://github.com/juanghurtado/less-elements.tmbundle>

Ruby gem to work with Rails: <https://github.com/krasnoukhov/lesselements-rails> 

License: This work is dedicated to the public domain and is free for all uses, commercial or otherwise. No form of credit required.