yn_getter = lambda x: x == 'yes'

yn_setter = lambda x: 'yes' if x else 'no'
