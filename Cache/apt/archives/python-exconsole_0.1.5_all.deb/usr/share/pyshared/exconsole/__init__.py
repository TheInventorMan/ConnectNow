from exconsole.console import register, launch

__version__ = '0.1.5'