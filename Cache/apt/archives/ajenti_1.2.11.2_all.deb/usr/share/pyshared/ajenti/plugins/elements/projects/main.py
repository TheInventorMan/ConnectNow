import cPickle
import json
import logging
import os
import subprocess
import shutil

try:
    from slugify import slugify
except:
    logging.error('Missing python-slugify module!')
    raise

import ajenti
from ajenti.api import *
from ajenti.api.http import HttpPlugin, url
from ajenti.plugins.main.api import SectionPlugin
from ajenti.plugins.services.api import ServiceMultiplexor
from ajenti.ui import on
from ajenti.ui.binder import Binder
from ajenti.plugins import manager
from ..usermgr import ElementsUserManager

from reconfigure.configs import SambaConfig, ExportsConfig, NetatalkConfig

import reconfigure.items.samba
import reconfigure.items.netatalk
import reconfigure.items.exports


SHARE_NAME = '__projects'
IDENTIFICATION_COMMENT = 'Created by Elements Storage, do not edit'
FS_ROOT = '/mnt/snfs1/'
ROOT = '/mnt/snfs1/.projects'
TEMPLATE_ROOT = '/var/lib/elements/templates'


# Detect components

snfs_present = os.path.exists('/usr/cvfs/bin/cvadmin')
if not snfs_present:
    logging.warn('SNFS support not present')

try:
    subprocess.check_call(['which', 'snquota'])
    subprocess.check_call(['snquota', '-L', '-Fsnfs1'])
    quotas_present = True
except:
    quotas_present = False
if not quotas_present:
    logging.warn('SNFS quota support not present')



class ElementsProject (object):
    def __init__(self):
        self.name = ''
        self.directory = ''
        self.permissions = []
        self.verify()

    @property
    def path(self):
        return os.path.join(ROOT, self.directory)

    def verify(self):
        if not hasattr(self, 'directory') or not self.directory:
            self.directory = slugify(self.name)
        defaults = {
            'description': '',
            'long_description': '',
            'emulate_avid': False,
            'share_nfs': False,
            'share_afp': False,
            'share_smb': False,
            'quota_size_soft': 0,
            'quota_size_hard': 0,
            'affinity': None,
        }
        for k, v in defaults.iteritems():
            if not hasattr(self, k):
                setattr(self, k, v)

        if os.listdir(FS_ROOT):
            if self.directory and not os.path.exists(self.path):
                os.mkdir(self.path)

    def json(self):
        return {
            'name': self.name,
            'path': self.path,
            'directory': self.directory,
            'emulate_avid': self.emulate_avid,
        }

    def is_allowed_for(self, user):
        umgr = ElementsUserManager.get(manager.context)
        for p in self.permissions:
            if p.user == user or umgr.user_in_group(user, p.user):
                return True
        return False


class ElementsProjectPermission (object):
    def __init__(self):
        self.project = None
        self.user = 'root'


@plugin
class ElementsProjectManager (BasePlugin):
    default_classconfig = {'projects': ''}
    classconfig_root = True

    def init(self):
        self.smb_config = SambaConfig(path='/etc/samba/smb.conf')
        self.afp_config = NetatalkConfig(path='/etc/afp.conf')
        self.nfs_config = ExportsConfig(path='/etc/exports')

        if os.listdir(FS_ROOT):
            if not os.path.exists(ROOT):
                os.mkdir(ROOT)
        else:
            return

        try:
            self.projects = cPickle.loads(str(self.classconfig['projects']))
        except:
            self.projects = []

        for p in self.projects:
            p.verify()

        self.active_users = {}

        self.affinities = []
        try:
            ll = subprocess.check_output(['/usr/cvfs/bin/cvadmin', '-e', 'select snfs1; show long']).splitlines()
            for l in ll:
                l = l.strip()
                if l.startswith('Affinity'):
                    self.affinities.append(l.split(':')[1].strip())
        except:
            pass

    def get_project(self, name):
        for p in self.projects:
            if p.name == name:
                return p
        return None

    def login(self, name, user):
        p = self.get_project(name)
        self.active_users.setdefault(user, set())
        if p:
            self.active_users[user].add(p)
        return True

    def logout(self, name, user):
        p = self.get_project(name)
        self.active_users.setdefault(user, set())
        if p:
            if p in self.active_users[user]:
                self.active_users[user].remove(p)
        else:
            del self.active_users[user]
        return False

    def __call_quota(self, p, args):
        d = subprocess.check_output(['snquota', '-F', 'snfs1', '-d', '.projects/' + p.directory] + args)
        return d

    def _parse_quotasize(self, s):
        sfx = s[-1]
        i = float(s[:-1])
        if sfx == 'K':
            i *= 1024
        if sfx == 'M':
            i *= 1024 ** 2
        if sfx == 'G':
            i *= 1024 ** 3
        if sfx == 'T':
            i *= 1024 ** 4
        return i / (1024 ** 3)

    def list_templates(self):
        return os.listdir(TEMPLATE_ROOT)

    def create_project(self, p, template=None):
        self.projects.append(p)
        p.verify()
        self.save()
        if template:
            shutil.rmtree(p.path)
            shutil.copytree(os.path.join(TEMPLATE_ROOT, template), p.path)
        subprocess.call(['chmod', '777', '-R', p.path])

    def delete_project(self, p):
        self.projects.remove(p)
        if quotas_present:
            self.__call_quota(p, ['-D'])

    def save(self, reload=True):
        self.smb_config.load()
        self.nfs_config.load()
        self.afp_config.load()

        for share in self.smb_config.tree.shares:
            if share.name == SHARE_NAME:
                self.smb_config.tree.shares.remove(share)
                continue
            if share.comment == IDENTIFICATION_COMMENT:
                try:
                    self.smb_config.tree.shares.remove(share)
                except:
                    pass

        for share in self.nfs_config.tree.exports:
            if share.comment == IDENTIFICATION_COMMENT:
                self.nfs_config.tree.exports.remove(share)

        for share in self.afp_config.tree.shares:
            if share.comment == IDENTIFICATION_COMMENT:
                self.afp_config.tree.shares.remove(share)

        getattr(self.afp_config.tree, 'global').uam_list = 'uams_guest.so,uams_clrtxt.so,uams_dhx.so'

        s = reconfigure.items.samba.ShareData()
        s.name = SHARE_NAME
        s.path = ROOT
        s.browseable = False
        s.read_only = False
        s.guest_ok = True
        s.create_mask = '0777'
        s.directory_mask = '0777'
        self.smb_config.tree.shares.append(s)


        for p in self.projects:
            if quotas_present:
                self.__call_quota(p, ['-C'])
                if p.quota_size_hard:
                    self.__call_quota(p, ['-S', '-h', '%sg' % p.quota_size_hard, '-s', '%sg' % p.quota_size_soft, '-t', '1d'])

            if p.share_smb:
                s = reconfigure.items.samba.ShareData()
                s.name = p.name
                s.comment = IDENTIFICATION_COMMENT
                s.path = os.path.join(ROOT, p.directory)
                s.read_only = False
                s.guest_ok = True
                self.smb_config.tree.shares.append(s)

            if p.emulate_avid:
                s = reconfigure.items.samba.ShareData()
                s.name = p.name + '_'
                s.comment = IDENTIFICATION_COMMENT
                s.path = os.path.join(ROOT, p.directory)
                s.read_only = False
                s.guest_ok = True
                s.fstype = 'AVIDFOS'
                self.smb_config.tree.shares.append(s)

            if p.share_nfs:
                s = reconfigure.items.exports.ExportData()
                s.name = os.path.join(ROOT, p.directory)
                c = reconfigure.items.exports.ClientData()
                c.name = '*'
                c.options = 'rw,insecure,no_subtree_check,rsize=2097152,wsize=2097152,async,tcp'
                s.comment = IDENTIFICATION_COMMENT
                s.clients.append(c)
                self.nfs_config.tree.exports.append(s)

            if p.share_afp:
                s = reconfigure.items.netatalk.ShareData()
                s.name = p.name
                s.comment = IDENTIFICATION_COMMENT
                s.path = os.path.join(ROOT, p.directory)
                s.read_only = False
                s.valid_users = 'root,client'
                self.afp_config.tree.shares.append(s)

            if snfs_present:
                if p.affinity:
                    subprocess.call(['/usr/cvfs/bin/cvaffinity', '-s', p.affinity, p.path])

        if quotas_present:
            # Read quota status
            q = json.loads(subprocess.check_output(['snquota', '-L', '-Fsnfs1', '-ojson']))
            q = q['directoryQuotas']
            for e in q:
                if e['type'] == 'dir':
                    for p in self.projects:
                        if e['name'] == '/.projects/' + p.directory:
                            p.quota_size_status = e['status']
                            try:
                                p.quota_size_current = self._parse_quotasize(e['curSize'])
                                p.quota_size_usage = p.quota_size_current / p.quota_size_hard
                            except:
                                p.quota_size_current = 0
                                p.quota_size_usage = 0

        self.smb_config.save()
        self.nfs_config.save()
        self.afp_config.save()

        if reload:
            ServiceMultiplexor.get().get_one('smb' if ajenti.platform == 'centos' else 'smbd').command('reload')
            subprocess.call(['exportfs', '-a'])
            #ServiceMultiplexor.get().get_one('nfs' if ajenti.platform == 'centos' else 'nfs-kernel-server').restart()
            #ServiceMultiplexor.get().get_one('netatalk').restart()
            subprocess.call(['pkill', '-HUP' 'afpd'])

        self.classconfig['projects'] = cPickle.dumps(self.projects)
        self.save_classconfig()


ElementsProjectManager.get().save(reload=False)


class StripeGroup (object):
    def __init__(self):
        pass

class StripeGroups (object):
    def __init__(self):
        self.groups = []

    def refresh(self):
        if subprocess.call(['which', 'cvadmin']) != 0:
            return
        self.groups = []
        ll = subprocess.check_output(['cvadmin', '-e', 'select snfs1; show'])
        g = None
        for l in ll.splitlines():
            l = l.strip()
            if l.startswith('Stripe Group '):
                g = StripeGroup()
                g.name = l.split('[')[1].split(']')[0]
                self.groups.append(g)
            if l.startswith('Total Blocks:'):
                g.usage = 1.0 - float(l.split('(')[-1][:-2]) / 100
                g.free = l.split('(')[-2].split(')')[0]


@plugin
class ElementsProjects (SectionPlugin):
    def init(self):
        self.title = 'Workspaces'
        self.icon = 'suitcase'
        self.category = 'Elements'
        self.append(self.ui.inflate('elements:projects-main'))

        self.find('permissions').new_item = lambda c: ElementsProjectPermission()

        def post_project_bind(o, c, i, u):
            def on_set_affinity():
                i.affinity = u.find('affinity').value
                self.save()
            u.find('set-affinity').on('click', on_set_affinity)

        self.find('projects').post_item_bind = post_project_bind
        self.find('projects').delete_item = lambda i, c: self.mgr.delete_project(i)

        self.mgr = ElementsProjectManager.get(manager.context)
        self.umgr = ElementsUserManager.get(manager.context)
        self.stripegroups = StripeGroups()
        self.binder = Binder(None, self)
        self.sg_binder = Binder(self.stripegroups, self.find('stripegroups'))

        self.find('affinity-box').visible = snfs_present
        self.find('quotas-box').visible = quotas_present
        if not quotas_present:
            self.find('quotas-tab').delete()

    def on_page_load(self):
        self.refresh()

    def refresh(self):
        self.stripegroups.refresh()
        self.sg_binder.reset().autodiscover().populate()

        self.binder.reset(self.mgr)
        self.find('affinity').labels = self.mgr.affinities
        self.find('affinity').values = self.mgr.affinities
        self.find('user-dropdown').labels = self.find('user-dropdown').values = [x.name for x in ajenti.config.tree.users.values()] + [x.name for x in self.umgr.groups]
        self.binder.autodiscover().populate()

        self.find('new-project-template').labels = ['None'] + self.mgr.list_templates()
        self.find('new-project-template').values = [''] + self.mgr.list_templates()
        self.find('new-project-template').value = ''

    @on('new-project', 'click')
    def on_new_project(self):
        template = self.find('new-project-template').value
        self.save()
        p = ElementsProject()
        p.name = self.find('new-project-name').value
        if p.name:
            self.mgr.create_project(p, template=template)
            self.refresh()
            self.find('new-project-name').value = ''

    @on('save', 'click')
    def save(self):
        self.binder.update()
        self.mgr.save()
        self.refresh()


@plugin
class ElementsProjectServer (HttpPlugin):
    def init(self):
        self.mgr = ElementsProjectManager.get(manager.context)

    @url('/elements/projects/(?P<endpoint>.+)')
    def get_page(self, context, endpoint):
        if context.session.identity is None:
            context.respond_forbidden()

        context.respond_ok()

        endpoint = endpoint.split('/')

        if endpoint[0] == 'test':
            return 'ok'

        if endpoint[0] == 'login':
            self.mgr.login(endpoint[1], context.session.identity)
            return 'ok'

        if endpoint[0] == 'logout':
            self.mgr.logout(endpoint[1], context.session.identity)
            return 'ok'

        if endpoint[0] == 'list-projects':
            return json.dumps([p.json() for p in self.mgr.projects if p.is_allowed_for(context.session.identity)])
