#ifndef _ASM_X86_SETUP_H
#define _ASM_X86_SETUP_H


#endif /* _ASM_X86_SETUP_H */
